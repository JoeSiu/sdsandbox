# Examples

some sample code to use the gym-donkeycar environment

## gym_test.py

Some minimal code to load the gym-donkeycar environment and test

## reinforcement_learning

A dir of sample code of [reinforcement learning](https://github.com/tawnkramer/gym-donkeycar/tree/master/examples/reinforcement_learning) with gym-donkeycar

## supervised_learning

A dir of sample code of [supervised learning](https://github.com/tawnkramer/gym-donkeycar/tree/master/examples/supervised_learning) with gym-donkeycar
