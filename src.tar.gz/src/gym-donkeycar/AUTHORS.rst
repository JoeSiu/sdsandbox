=======
Credits
=======


Contributors
------------

* Tawn Kramer @tawnkramer (original source: https://github.com/tawnkramer/gym-donkeycar)
* Roma Sokolkov @r7vme (https://github.com/r7vme/gym-donkeycar) forked from (https://github.com/tawnkramer/sdsandbox)
* Leigh Johnson @leigh-johnson <leigh@data-literate.com>
* Maxime Ellerbach `@Maximellerbach <https://github.com/Maximellerbach>`_
* Antonin Raffin `@araffin <https://araffin.github.io/>`_
