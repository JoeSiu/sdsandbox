=====
Usage
=====

To use OpenAI Gym Environments for Donkey Carin a project::

    import gym_donkeycar
