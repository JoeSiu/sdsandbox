class SimFailed(Exception):
    pass
